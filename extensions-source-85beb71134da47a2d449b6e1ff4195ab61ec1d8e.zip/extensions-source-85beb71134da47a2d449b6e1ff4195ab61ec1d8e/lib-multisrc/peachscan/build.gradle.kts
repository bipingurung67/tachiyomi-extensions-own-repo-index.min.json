plugins {
    id("lib-multisrc")
}

baseVersionCode = 6

dependencies {
    compileOnly("com.github.tachiyomiorg:image-decoder:e08e9be535")
}

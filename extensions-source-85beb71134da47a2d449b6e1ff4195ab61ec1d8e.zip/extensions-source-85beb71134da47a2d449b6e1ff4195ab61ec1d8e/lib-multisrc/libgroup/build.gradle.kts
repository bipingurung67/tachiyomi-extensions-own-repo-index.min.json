plugins {
    id("lib-multisrc")
}

baseVersionCode = 25

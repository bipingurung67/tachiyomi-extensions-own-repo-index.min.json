plugins {
    id("lib-multisrc")
}

baseVersionCode = 3

dependencies {
    api(project(":lib:synchrony"))
}

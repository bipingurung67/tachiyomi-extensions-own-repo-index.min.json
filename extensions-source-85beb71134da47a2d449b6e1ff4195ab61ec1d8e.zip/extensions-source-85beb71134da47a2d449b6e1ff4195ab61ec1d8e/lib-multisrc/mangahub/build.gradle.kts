plugins {
    id("lib-multisrc")
}

baseVersionCode = 28

dependencies {
    api(project(":lib:randomua"))
}

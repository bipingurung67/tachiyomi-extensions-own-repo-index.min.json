plugins {
    id("lib-multisrc")
}

baseVersionCode = 30

dependencies {
    api(project(":lib:i18n"))
}

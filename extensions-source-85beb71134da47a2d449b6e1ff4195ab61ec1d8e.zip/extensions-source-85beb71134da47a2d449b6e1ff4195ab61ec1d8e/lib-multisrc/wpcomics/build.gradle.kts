plugins {
    id("lib-multisrc")
}

baseVersionCode = 5

dependencies {
    api(project(":lib:i18n"))
}

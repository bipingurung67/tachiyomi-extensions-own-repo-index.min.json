plugins {
    id("lib-multisrc")
}

baseVersionCode = 23

dependencies {
    api(project(":lib:i18n"))
}

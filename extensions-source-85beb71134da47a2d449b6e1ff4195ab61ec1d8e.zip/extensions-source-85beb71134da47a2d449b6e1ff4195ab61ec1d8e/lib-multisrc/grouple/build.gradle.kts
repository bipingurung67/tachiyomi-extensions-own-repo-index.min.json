plugins {
    id("lib-multisrc")
}

baseVersionCode = 22

plugins {
    id("lib-multisrc")
}

baseVersionCode = 7

dependencies {
    api(project(":lib:speedbinb"))
}

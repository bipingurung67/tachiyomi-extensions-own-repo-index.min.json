plugins {
    id("lib-multisrc")
}

baseVersionCode = 6

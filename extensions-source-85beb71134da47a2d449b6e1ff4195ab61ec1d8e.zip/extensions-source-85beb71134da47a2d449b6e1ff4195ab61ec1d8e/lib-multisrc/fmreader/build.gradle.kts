plugins {
    id("lib-multisrc")
}

baseVersionCode = 9

plugins {
    id("lib-multisrc")
}

baseVersionCode = 8

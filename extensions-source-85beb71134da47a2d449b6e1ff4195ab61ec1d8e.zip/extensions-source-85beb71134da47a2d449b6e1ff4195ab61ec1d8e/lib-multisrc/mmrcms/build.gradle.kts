plugins {
    id("lib-multisrc")
}

baseVersionCode = 11

dependencies {
    api(project(":lib:i18n"))
}

plugins {
    id("lib-multisrc")
}

baseVersionCode = 13

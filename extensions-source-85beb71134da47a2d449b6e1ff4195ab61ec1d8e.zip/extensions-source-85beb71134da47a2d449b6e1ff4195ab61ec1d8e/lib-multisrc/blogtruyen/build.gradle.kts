plugins {
    id("lib-multisrc")
}

baseVersionCode = 1

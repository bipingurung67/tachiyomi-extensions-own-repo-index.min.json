package eu.kanade.tachiyomi.extension.en.assortedscans

import eu.kanade.tachiyomi.multisrc.mangadventure.MangAdventure

class AssortedScans : MangAdventure("Assorted Scans", "https://assortedscans.com", "en")

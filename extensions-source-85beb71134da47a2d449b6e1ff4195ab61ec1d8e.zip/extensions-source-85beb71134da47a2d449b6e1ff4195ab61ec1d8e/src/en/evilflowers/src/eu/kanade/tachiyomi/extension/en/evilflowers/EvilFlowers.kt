package eu.kanade.tachiyomi.extension.en.evilflowers

import eu.kanade.tachiyomi.multisrc.foolslide.FoolSlide

class EvilFlowers : FoolSlide("Evil Flowers", "https://reader.evilflowers.com", "en")

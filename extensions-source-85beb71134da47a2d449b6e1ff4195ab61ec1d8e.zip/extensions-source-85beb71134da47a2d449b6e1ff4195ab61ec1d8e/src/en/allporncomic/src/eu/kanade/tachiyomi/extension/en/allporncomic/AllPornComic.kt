package eu.kanade.tachiyomi.extension.en.allporncomic

import eu.kanade.tachiyomi.multisrc.madara.Madara

class AllPornComic : Madara("AllPornComic", "https://allporncomic.com", "en")

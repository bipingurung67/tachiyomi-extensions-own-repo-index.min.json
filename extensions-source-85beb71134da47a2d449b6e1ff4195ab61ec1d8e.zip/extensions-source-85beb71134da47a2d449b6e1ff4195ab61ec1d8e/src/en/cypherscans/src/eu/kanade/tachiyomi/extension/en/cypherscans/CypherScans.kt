package eu.kanade.tachiyomi.extension.en.cypherscans

import eu.kanade.tachiyomi.multisrc.mangathemesia.MangaThemesia

class CypherScans : MangaThemesia("Cypher Scans", "https://cypherscans.xyz", "en")

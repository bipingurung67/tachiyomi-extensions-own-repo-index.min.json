package eu.kanade.tachiyomi.extension.en.adultwebtoon

import eu.kanade.tachiyomi.multisrc.madara.Madara

class AdultWebtoon : Madara("Adult Webtoon", "https://adultwebtoon.com", "en") {
    override val mangaSubString = "adult-webtoon"
}

package eu.kanade.tachiyomi.extension.en.deathtollscans

import eu.kanade.tachiyomi.multisrc.foolslide.FoolSlide

class DeathTollScans : FoolSlide("Death Toll Scans", "https://reader.deathtollscans.net", "en")

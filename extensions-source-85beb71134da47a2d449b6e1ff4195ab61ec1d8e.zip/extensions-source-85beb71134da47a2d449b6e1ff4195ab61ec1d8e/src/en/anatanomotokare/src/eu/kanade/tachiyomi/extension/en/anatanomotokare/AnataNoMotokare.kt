package eu.kanade.tachiyomi.extension.en.anatanomotokare

import eu.kanade.tachiyomi.multisrc.foolslide.FoolSlide

class AnataNoMotokare : FoolSlide("Anata no Motokare", "https://motokare.xyz", "en", "/reader")

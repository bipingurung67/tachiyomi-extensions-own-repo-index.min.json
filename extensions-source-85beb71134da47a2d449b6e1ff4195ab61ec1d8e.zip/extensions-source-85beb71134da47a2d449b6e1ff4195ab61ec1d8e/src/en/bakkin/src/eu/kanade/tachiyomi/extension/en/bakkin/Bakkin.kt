package eu.kanade.tachiyomi.extension.en.bakkin

import eu.kanade.tachiyomi.multisrc.bakkin.BakkinReaderX

class Bakkin : BakkinReaderX("Bakkin", "https://bakkin.moe/reader/", "en")

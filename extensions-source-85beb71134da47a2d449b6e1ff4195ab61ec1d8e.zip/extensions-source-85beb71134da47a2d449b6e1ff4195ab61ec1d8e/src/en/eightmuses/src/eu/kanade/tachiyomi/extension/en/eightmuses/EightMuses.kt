package eu.kanade.tachiyomi.extension.en.eightmuses

import eu.kanade.tachiyomi.multisrc.eromuse.EroMuse
import kotlin.ExperimentalStdlibApi

@ExperimentalStdlibApi
class EightMuses : EroMuse("8Muses", "https://comics.8muses.com")

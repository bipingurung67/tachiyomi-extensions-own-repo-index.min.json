package eu.kanade.tachiyomi.extension.en.beehentai

import eu.kanade.tachiyomi.multisrc.madtheme.MadTheme

class BeeHentai : MadTheme("BeeHentai", "https://beehentai.com", "en")

package eu.kanade.tachiyomi.extension.en.galaxydegenscans

import eu.kanade.tachiyomi.multisrc.madara.Madara

class GalaxyDegenScans : Madara("GalaxyDegenScans", "https://gdscans.com", "en")

package eu.kanade.tachiyomi.extension.en.animatedglitchedscans

import eu.kanade.tachiyomi.multisrc.mangathemesia.MangaThemesia

class AnimatedGlitchedScans : MangaThemesia("Animated Glitched Scans", "https://anigliscans.xyz", "en", mangaUrlDirectory = "/series")

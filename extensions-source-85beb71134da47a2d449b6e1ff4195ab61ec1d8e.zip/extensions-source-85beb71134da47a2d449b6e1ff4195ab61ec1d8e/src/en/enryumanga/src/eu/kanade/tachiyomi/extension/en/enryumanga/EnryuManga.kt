package eu.kanade.tachiyomi.extension.en.enryumanga

import eu.kanade.tachiyomi.multisrc.mangathemesia.MangaThemesia

class EnryuManga : MangaThemesia("EnryuManga", "https://enryumanga.com", "en")

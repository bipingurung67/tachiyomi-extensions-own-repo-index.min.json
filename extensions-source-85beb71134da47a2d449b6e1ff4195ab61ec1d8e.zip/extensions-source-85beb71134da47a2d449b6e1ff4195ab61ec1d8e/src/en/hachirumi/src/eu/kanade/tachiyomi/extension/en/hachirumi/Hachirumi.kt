package eu.kanade.tachiyomi.extension.en.hachirumi

import eu.kanade.tachiyomi.multisrc.guya.Guya

class Hachirumi : Guya("Hachirumi", "https://hachirumi.com", "en")

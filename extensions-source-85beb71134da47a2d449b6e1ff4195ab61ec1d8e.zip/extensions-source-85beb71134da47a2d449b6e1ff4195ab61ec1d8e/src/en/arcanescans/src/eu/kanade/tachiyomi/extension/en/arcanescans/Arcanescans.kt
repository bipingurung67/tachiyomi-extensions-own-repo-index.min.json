package eu.kanade.tachiyomi.extension.en.arcanescans

import eu.kanade.tachiyomi.multisrc.madara.Madara

class Arcanescans : Madara("Arcanescans", "https://arcanescans.com", "en")

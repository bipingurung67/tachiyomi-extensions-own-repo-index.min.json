package eu.kanade.tachiyomi.extension.en.harimanga

import eu.kanade.tachiyomi.multisrc.madara.Madara

class Harimanga : Madara("Harimanga", "https://harimanga.com", "en")

package eu.kanade.tachiyomi.extension.en.dankefurslesen

import eu.kanade.tachiyomi.multisrc.guya.Guya

class DankeFursLesen : Guya("Danke fürs Lesen", "https://danke.moe", "en")

package eu.kanade.tachiyomi.extension.en.guya

import eu.kanade.tachiyomi.multisrc.guya.Guya

class Guya : Guya("Guya", "https://guya.cubari.moe", "en")

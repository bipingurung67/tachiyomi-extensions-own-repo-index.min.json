package eu.kanade.tachiyomi.extension.en.blackoutscans

import eu.kanade.tachiyomi.multisrc.keyoapp.Keyoapp

class BlackoutScans : Keyoapp("Blackout Scans", "https://blackoutscans.com", "en")

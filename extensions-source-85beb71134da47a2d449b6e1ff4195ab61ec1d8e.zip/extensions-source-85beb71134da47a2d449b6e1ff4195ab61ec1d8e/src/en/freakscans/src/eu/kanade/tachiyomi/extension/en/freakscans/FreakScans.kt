package eu.kanade.tachiyomi.extension.en.freakscans

import eu.kanade.tachiyomi.multisrc.mangathemesia.MangaThemesia

class FreakScans : MangaThemesia("Freak Scans", "https://freakscans.com", "en")

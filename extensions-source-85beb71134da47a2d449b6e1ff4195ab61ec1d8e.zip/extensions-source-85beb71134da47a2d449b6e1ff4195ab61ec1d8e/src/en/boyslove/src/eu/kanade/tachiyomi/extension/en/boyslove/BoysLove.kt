package eu.kanade.tachiyomi.extension.en.boyslove

import eu.kanade.tachiyomi.multisrc.madara.Madara

class BoysLove : Madara("BoysLove", "https://boyslove.me", "en")

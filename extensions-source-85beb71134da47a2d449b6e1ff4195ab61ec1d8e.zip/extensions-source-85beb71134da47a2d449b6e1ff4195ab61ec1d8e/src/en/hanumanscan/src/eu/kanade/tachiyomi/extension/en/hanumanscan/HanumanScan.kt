package eu.kanade.tachiyomi.extension.en.hanumanscan

import eu.kanade.tachiyomi.multisrc.mangathemesia.MangaThemesia

class HanumanScan : MangaThemesia("Hanuman Scan", "https://hanumanscan.com", "en")

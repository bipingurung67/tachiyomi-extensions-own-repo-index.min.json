package eu.kanade.tachiyomi.extension.en.comic1000

import eu.kanade.tachiyomi.multisrc.manga18.Manga18

class Comic1000 : Manga18("Comic1000", "https://comic1000.com", "en")

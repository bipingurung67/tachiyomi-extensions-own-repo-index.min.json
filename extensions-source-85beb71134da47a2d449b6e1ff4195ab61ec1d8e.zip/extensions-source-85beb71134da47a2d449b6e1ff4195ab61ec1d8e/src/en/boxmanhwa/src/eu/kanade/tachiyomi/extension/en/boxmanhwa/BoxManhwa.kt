package eu.kanade.tachiyomi.extension.en.boxmanhwa

import eu.kanade.tachiyomi.multisrc.madtheme.MadTheme

class BoxManhwa : MadTheme("BoxManhwa", "https://boxmanhwa.com", "en")

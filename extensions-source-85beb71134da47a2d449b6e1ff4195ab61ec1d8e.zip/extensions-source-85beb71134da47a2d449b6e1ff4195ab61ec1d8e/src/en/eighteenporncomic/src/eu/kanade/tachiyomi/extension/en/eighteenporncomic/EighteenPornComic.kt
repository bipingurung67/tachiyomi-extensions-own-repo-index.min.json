package eu.kanade.tachiyomi.extension.en.eighteenporncomic

import eu.kanade.tachiyomi.multisrc.manga18.Manga18

class EighteenPornComic : Manga18("18 Porn Comic", "https://18porncomic.com", "en")

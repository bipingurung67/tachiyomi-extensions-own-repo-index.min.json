# Cubari

Table of Content
- [FAQ](#FAQ)
  - [Why do I see no manga?](#why-do-i-see-no-manga)
  - [Where can I get more information about Cubari?](#where-can-i-get-more-information-about-cubari)
  - [How do I add a gallery to Cubari?](#how-do-i-add-a-gallery-to-cubari)

[Uncomment this if needed; and replace &#40; and &#41; with ( and )]: <> (- [Guides]&#40;#Guides&#41;)

Don't find the question you are look for go check out our general FAQs and Guides over at [Extension FAQ](https://tachiyomi.org/help/faq/#extensions) or [Getting Started](https://tachiyomi.org/help/guides/getting-started/#installation)

## FAQ

### Why do I see no manga?
Cubari is a proxy for image galleries.
If you've setup the Remote Storage via WebView the Recent tab shows your recent, unpinned entries, conversely the Popular tab shows your pinned entries.

### Where can I get more information about Cubari?
You can visit the [Cubari](https://cubari.moe/) website for for more information.

### How do I add a gallery to Cubari?
You can directly open a imgur or Cubari link in the extension.

[Uncomment this if needed]: <> (## Guides)
